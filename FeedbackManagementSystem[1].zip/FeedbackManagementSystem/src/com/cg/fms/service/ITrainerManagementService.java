package com.cg.fms.service;

import com.cg.fms.entites.Employee;

public interface ITrainerManagementService {

	public Employee addTrainer(Employee emp);
	
}
