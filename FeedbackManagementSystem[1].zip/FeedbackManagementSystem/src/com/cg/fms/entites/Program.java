package com.cg.fms.entites;

import java.time.LocalDate;

public class Program {
private String trainingId;
private LocalDate startDate;
private LocalDate endDate;
private Course course;
private Employee faculty;
}
