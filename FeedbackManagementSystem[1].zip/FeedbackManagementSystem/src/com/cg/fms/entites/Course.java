package com.cg.fms.entites;

public class Course {

	private String courseId;
	private String courseName;
	private String courseDescription;
	private int noOfDays;
	
}
