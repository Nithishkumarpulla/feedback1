package com.cg.fms.entites;

public class Employee {

	private int employeeId;
	private String empName;
	private String password;
	private Role role;
}
