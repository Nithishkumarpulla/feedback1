package com.cg.fms.entites;

public class Feedback {

	private Employee participant;
	private Program program;
	private int feedbackCriteria1;
	private int feedbackCriteria2;
	private int feedbackCriteria3;
	private int feedbackCriteria4;
	private int feedbackCriteria5;
	private String comments;
	private String suggestions;
	
}
