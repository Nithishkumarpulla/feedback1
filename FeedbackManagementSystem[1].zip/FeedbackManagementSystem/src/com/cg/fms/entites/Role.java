package com.cg.fms.entites;

public enum Role {

	admin,coordinator,participant;
}
