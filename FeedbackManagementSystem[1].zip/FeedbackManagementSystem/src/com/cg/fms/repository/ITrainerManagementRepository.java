package com.cg.fms.repository;

import com.cg.fms.entites.Employee;

public interface ITrainerManagementRepository {

	public Employee addTrainer(Employee emp);
	
}
