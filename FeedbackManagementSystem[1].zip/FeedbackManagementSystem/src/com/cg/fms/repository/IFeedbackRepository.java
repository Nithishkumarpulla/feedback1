package com.cg.fms.repository;

import java.util.List;

import com.cg.fms.entites.Feedback;
import com.cg.fms.entites.Program;

public interface IFeedbackRepository {

public Feedback addFeedback(Feedback fd);
public Feedback updateFeedback(Feedback fd);

public List<Feedback> viewTrainerFeedback(int trainerid);
public List<Feedback> viewProgramFeedback(Program program);

}
